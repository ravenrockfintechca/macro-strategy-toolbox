# Macro Strategy Toolbox

This repository consolidates the world's most influential macro trading strategies from verified GitHub sources.
Includes CPI forecasting, yield curve inversion detection, recession probability modeling, and more.
